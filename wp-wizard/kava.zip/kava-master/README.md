# kava
Kava Theme. Get the truly easy-to-use free theme with tons of functionality and perfect design!

## Changelog

### 1.2.3
- UPD: New Google fonts for Customizer

### 1.2.2
- FIX: Version

### 1.2.1
- UPD: WooCommerce widget styles

### 1.2.0
- FIX: prevent error in PHP 7.2 on a single post if an empty excerpt
- FIX: visibility comment meta on single post
- FIX: minor style for single posts layouts
- FIX: sidebar visibility on Vertical-Justify Blog Layout
- FIX: masonry posts listing on IOS
- DEL: unused framework modules
- FIX: shop sidebar no widgets issue
- UPD: pagination styles
- FIX: single product tabs styles

### 1.1.0
- FIX: Minor CSS fixes
- ADD: Português(Brasil) translation
- ADD: Archives location for Elementor Pro and JetThemeCore
- ADD: Single location for Elementor Pro and JetThemeCore
